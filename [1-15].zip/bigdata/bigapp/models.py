from djongo import models

class Travel(models.Model):
    city = models.CharField(max_length=100)

    def _str_(self):
        return self.city

