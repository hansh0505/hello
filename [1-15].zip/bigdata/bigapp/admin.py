from django.contrib import admin
from .models import Travel
# Register your models here.

admin.site.register(Travel)